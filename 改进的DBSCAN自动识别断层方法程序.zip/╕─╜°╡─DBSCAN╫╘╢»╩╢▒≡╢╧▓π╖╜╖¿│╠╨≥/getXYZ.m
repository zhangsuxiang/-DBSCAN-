function X = getXYZ(originalData)
    cloumnSize=3;
    m=size(originalData,1);
    X=zeros(m,cloumnSize);
    
    X(:,1)=originalData(:,3);
    X(:,2)=originalData(:,2);
    X(:,3)=originalData(:,4);
end