clear;
clc;
close all;
tangshan=xlsread('Example-tangshan.xlsx');    %input������γ���𼶺����
% tangshan=load('lushan.txt');
data=[tangshan(:,1), tangshan(:,2),tangshan(:,3),tangshan(:,4)]';%��ȡ���ȣ�γ�ȣ��𼶺����
data8=[data(1,:);data(2,:);data(4,:)]'; %���ȡ�γ�ȡ����
% ind0=find(data(:,4)==0);          % Ѱ�����Ϊ�����Ч����
% data(ind0,:)=[];                  % ɾ�����Ϊ�����Ч����
% [m,n]=size(data);                 % ��Ч���ݵĴ�С
% % p=data(1:2,:)';
% X=[data(2,:);data(1,:);data(3,:);data(4,:)]';
% X=X1(:,3:4);
% axesm utm;
% Z=utmzone(X(1,1),X(1,2));
% setm(gca,'zone',Z)
% h = getm(gca);
% R=zeros(length(X),2);
% for m=1:length(X)
%     [x,y]= mfwdtran(h,X(m,1),X(m,2));
%     R(m,:)=[x;y];
% end

%%KNN k distance graph, to determine the epsilon
% A=R/1000;
% numData=size(A,1);
% Kdist=zeros(numData,1);
% [IDX,Dist]=knnsearch(A(2:numData,:),A(1,:));
% Kdist(1)=Dist;
% for m=2:size(A,1)
%     [IDX,Dist] = knnsearch(A([1:m-1,m+1:numData],:),A(m,:));
%     Kdist(m)=Dist;
% end
% [sortKdist,sortKdistIdx]=sort(Kdist,'descend');
% distX=[1:numData]';
% plot(distX,sortKdist,'r+-','LineWidth',2);
% set(gcf,'position',[1000 340 350 350]);
% grid on;
 
%% Run DBSCAN Clustering Algorithm
%for epsilon=[3.0, 2.8, 2.5, 2.0, 1.8]
 %   for MinPts= [120, 100, 80, 70, 60]
eps=xlsread('eps.xlsx');         %eps��ѡ��������
minpts=xlsread('minpts.xlsx');    %eps��ѡ��������


epsilon=eps(1,10);        %������Ϊ����Kֵ���˴�����KֵΪ10
MinPts= minpts(1,10);         %��С�¼���minPts����Ϊ����Kֵ���˴�����KֵΪ10
IDX1=DBSCAN(data8,epsilon,MinPts);
%% Plot Results
figure(3);
PlotClusterinResult(IDX1,data');
%title(['DBSCAN Clustering (\epsilon = ' num2str(epsilon) ', MinPts = ' num2str(MinPts) ')']);
legend('�����¼�', '��ɽ���ѱ���1', '���ض��Ѷ�', '���ض��ѱ���', '��ɽ���ѱ���2','С��ׯ���Ѷ�','С��ׯ���Ѷ�','С��ׯ���Ѷ�','С��ׯ���Ѷ�','С��ׯ���Ѷ�' );
text(0.2,0.2,'(b)');
text(118.4, 39.87,'1','FontSize',20,'Color','red');
text(118.5, 39.55,'2','FontSize',20,'Color','red');
text(118.75, 39.6,'3','FontSize',20,'Color','red');
text(118.62, 39.6,'4','FontSize',20,'Color','red');
text(118.2, 39.75,'5','FontSize',20,'Color','red');
set(gcf,'position',[530 -10 500 500]);



data1=[];
data2=[];
for i=1:length(data8)
    if IDX1(i)==1                         %���Ų����£�ָ��ĳһ����
        data1=[data1,data(:,i)];
        % plot(A(i,1),A(i,2),'o')
%             elseif IDX1(i)==0             %IDX=0Ϊ�����������¼���
%                 data2=[data2,data(:,i)];
%                 xlswrite('C:\�Զ�ʶ��ϲ�����\result\Tangshan_surplus1.xlsx',data2')        %�����ܶ�ʶ��ϲ��������д���ļ�
%                 hold on;
    end
end
data1=data1';
set(gca,'box','on');
% xlswrite('C:\�Զ�ʶ��ϲ�����\result\tangshan_1.xlsx',data1);         %������ָ���������¼�д���ļ�
%% ����
dataori=data1;
   
% indlat=find((dataori(:,4)>5));
% dataori=dataori(indlat,:);

%ת������ km
lat = dataori(:,2); long = dataori(:,1); deep = dataori(:,4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lat0=mean(lat);
long0=mean(long);
dep0=mean(deep);
% ����ƽ��λ�� m=[39.9458 113.8313]
%[y,x]=gdist(lat,long,lat0,long0);
c1 = 111.199;
x = c1*(lat-lat0);
rlat = (lat+lat0)*pi/360;
y = c1*(long-long0).*cos(rlat);
%z = deep;%r-mean(r);clc
z = deep-dep0; %clc
%dat=[x,y,z,sqrt((dataori(:,8)/1000).^2+(dataori(:,9)/1000).^2+(dataori(:,10)/1000).^2)];
dat=[x,y,z,ones(size(x))];   %Assume that the error is 1
%Because the unit of error in hypoDD is m. 
%The 4 column is error

% tic
bound = [0 2*pi;0 pi/2;-5 5];
[m,n] = size(bound);
%D = bound(:,1);
%U = bound(:,2);
%generate a solution by random
for ii = 1: m
x0(ii,1) =bound(ii,1)+rand*(bound(ii,2)-bound(ii,1)) ;
end
T = 10^3;              % intial temperature
T0 = 0.0001 ;          % final  temperature
alpha = 0.95 ;         % alpha in [0.85 0.98]
eps=10^(-8);           % eps = 0.001;
maxTrialN = 50;
k=0;                   % ���������ļ�����
Energy = dzsjsph_sa(x0,dat);
while ((T>T0)& (Energy>eps)&(k<300))
    k=k+1;
    [x0,Energy] = Annealingdizhennihe(x0,dat,T,Energy,maxTrialN);
%    [x0,Energy] = Annealingbound(x0,dat,T,Energy,maxTrialN,bound);
    T = alpha*T;      % �˻����
end
% toc
% disp('SAA�㷨 ��С������ϲ���[����ǣ�����ǣ���ԭ�����]');
% disp(num2str([rad2deg(x0(1:2,1)); x0(3,1)]'));
% disp('SAA�㷨 ��Ӧ�ķ�����Ϊ');
phi = x0(1,1); delta = x0(2,1);
nv = [sin(phi)*sin(delta), -cos(phi)*sin(delta), cos(delta)];
% disp(num2str(nv));
% disp('SAA�㷨 ��Ӧ�ļ�Сֵ������С�������ƽ����');
% disp(num2str(Energy));

%%%% The follwing is the Newton-Gauss algorithm

%Gauss-Newton������
x0=x0;eps=10^(-7);                 % ����ģ���˻��㷨������������Gauss_Newton
[m,n]=size(dat);
Cd=diag(dat(:,4).^2); 
%Cd=eye(length(dat),length(dat));  % If we cannot find error we use these
Cd_1=inv(Cd);
for m = 1:100
    A = goalvectorJsph(x0',dat);   % Jacobi����
    cvsv=A'*Cd_1*A;
    cvinv=inv(cvsv);
    xx=cvinv*A'*Cd_1*goalvectorsph(x0',dat);
    x1 = x0 -xx;
    R=cvinv*cvsv;
    if norm(x1-x0)>eps
        x0 =x1;
    else
        break;
    end
end
 chsq_dt=xx'*cvsv*xx;
 y=goalvectorsph(x1',dat);
 tot= y'*Cd_1*y;
 chsq_pst = tot - chsq_dt;
 rsl_sum=sum([R(1,1),R(2,2),R(3,3)]);
 rchisq = chsq_pst/(m-rsl_sum);
    sd=[];
    for ii=1:n-1                  % because we add error in 
    sd1=sqrt(cvinv(ii,ii)*rchisq);
%    sd1=sqrt(cvinv(ii,ii));
    sd=[sd,sd1];
    end
    if(x1(2,1)<0)
        x1(2,1)=pi/2-x1(2,1);
         if(x1(1,1)>pi)
          x1(1,1)=x1(1,1)-pi;
        else
          x1(1,1)=x1(1,1)+pi;  
         end
    elseif(x1(2,1)>pi/2)
        x1(2,1)=x1(2,1)-pi/2;
           if(x1(1,1)>pi)
          x1(1,1)=x1(1,1)-pi;
        else
          x1(1,1)=x1(1,1)+pi;  
         end
    end    
sprintf('The iterative number is %d',m) 
disp('G-S�㷨 ��С������ϲ���[����ǣ�����ǣ���ԭ�����]')
disp(num2str([rad2deg(x1(1:2)); x1(3)]'));
% disp('G-S�㷨 ��Ӧ�ķ�����Ϊ')
% phi = x1(1); delta = x1(2);
% nv = [sin(phi)*sin(delta), -cos(phi)*sin(delta), cos(delta)];
% disp(num2str(nv))
% disp('G-S�㷨 ��Ӧ�ļ�Сֵ������С�������ƽ����')

[m,n] = size(dat);
errsumv =zeros(m,1);
x = x1;
for m=1:m
       errsumv(m) = (sin(x(1))*sin(x(2))*dat(m,1) +(-cos(x(1)))*sin( x(2))*dat(m,2) + cos(x(2))*dat(m,3) -x(3))/dat(m,4);
end
errsum=sum(errsumv.^2);
disp(num2str(errsum))
disp('��׼�')
sd
[rad2deg(sd(1:2)) sd(3)];
disp('�ݺ�в�:')
 chsq_pst = tot - chsq_dt
 rsl_sum=sum([R(1,1),R(2,2),R(3,3)]);
disp('ƽ���ݺ�в�:')
 rchisq = chsq_pst/(m-rsl_sum)
%%%    ����Ϊ��ת������     %%%%%%%%%%%
n=size(dat,1);                          % ������
p=0.025;                                % ����ˮƽ
nd= ceil(n*p);                          % ��Ե�������
phirad=x1(1);deltarad =x1(2);
R1=[1 0  0;0 cos(deltarad)  sin(deltarad);0 -sin(deltarad) cos(deltarad)];
R2=[cos(phirad) sin(phirad) 0;-sin(phirad) cos(phirad) 0;0 0 1 ];
datr2=R1*(R2*dat(:,1:3)');
STR = sortrows(datr2',1);
DIP = sortrows(datr2',2);
stredge = [STR(nd,1),  STR(n-nd,1)];
dipedge =  [DIP(nd,2),  DIP(n-nd,2) ];
P=[stredge(1) dipedge(1)  0;...         % left upper point
    stredge(1) dipedge(2)  0;...        % left down point
    stredge(2) dipedge(2)  0;...        % right down point
    stredge(2) dipedge(1)  0;...        % right upper point
    stredge(1) dipedge(1)  0            % left upper point
    ];  
%��Ϊ�ڶϲ����ϣ�����ڶϲ����ϵ�Z����Ϊ��   

figure(1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2
subplot(2,2,2)
plot([stredge(1),stredge(1),stredge(2),stredge(2),stredge(1)],[dipedge(1),dipedge(2),dipedge(2),dipedge(1),dipedge(1)],'k','LineWidth',2)
hold on
if(phi<=pi/2)
S1=sprintf('S%3.0f^oW',rad2deg(phi));
S2=sprintf('N%3.0f^oE',rad2deg(phi));
elseif(phi>pi/2&phi<=pi)
S1=sprintf('N%3.0f^oW',rad2deg(pi-phi));
S2=sprintf('S%3.0f^oE',rad2deg(pi-phi));
elseif(phi>pi&phi<=3/2*pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-pi));
S2=sprintf('S%3.0f^oW',rad2deg(phi-pi));
elseif(phi>3/2*pi&phi<=2*pi)
S1=sprintf('N%3.0f^oW',rad2deg(2*pi-phi));
S2=sprintf('S%3.0f^oE',rad2deg(2*pi-phi));
end
%scatter(datr2(1,:),datr2(2,:),(dataori(:,17)+1).^2,dat(:,4))
scatter(datr2(1,:),datr2(2,:),(dataori(:,3)+1).^1.0,'k')
set(gca,'box','on')
set(gca,'Ydir','reverse','box','on')
axis equal
Xm=xlim;Ym=ylim;
text(Xm(1)+(Xm(2)-Xm(1))/10-20,Ym(1)+(Ym(2)-Ym(1))/10-20,S1)
text(Xm(2)-(Xm(2)-Xm(1))/10-3,Ym(1)+(Ym(2)-Ym(1))/10-20,S2)
text(Xm(2)-(Xm(2)-Xm(1))/10,Ym(1)+(Ym(2)-Ym(1))/10,'(b)')
text(stredge(1)-1,dipedge(1)-5,'A')
text(stredge(2)+1,dipedge(1)-5,'A''')
xlabel('SD/km')
ylabel('DD/km')
set(gca,'LineWidth',1)
%colorbar

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 3
subplot(2,2,3)
R11=[1 0 0;0 1 0;0 0 1 ];
R22 = [1 0  0;0 cos(deltarad)  -sin(deltarad);0 sin(deltarad) cos(deltarad)];
X=R11*(R22*datr2);
%scatter(X(2,:),X(3,:)+dep0,(dataori(:,17)+1).^2,dat(:,4))
scatter(X(2,:),X(3,:)+dep0,(dataori(:,3)+1).^2,'k')
PP=R11*(R22*P');
hold on
plot(PP(2,:),PP(3,:)+dep0,'k','LineWidth',3)
if(phi<=pi/2)
S1=sprintf('N%3.0f^oW',rad2deg(pi/2-phi));
S2=sprintf('S%3.0f^oE',rad2deg(pi/2-phi));
elseif(phi>pi/2&phi<=pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-pi/2));
S2=sprintf('S%3.0f^oW',rad2deg(phi-pi/2));
elseif(phi>pi&phi<=3*pi/2)
S1=sprintf('S%3.0f^oE',rad2deg(3/2*pi-phi));
S2=sprintf('N%3.0f^oW',rad2deg(3/2*pi-phi));
elseif(phi>3/2*pi&phi<=2*pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-3/2*pi));
S2=sprintf('S%3.0f^oW',rad2deg(phi-3/2*pi));
end
axis equal
set(gca,'Ydir','reverse','box','on')
Xm=xlim;Ym=ylim;
text(Xm(1)+(Xm(2)-Xm(1))/10-5,Ym(1)+(Ym(2)-Ym(1))/10-5,S1)
text(Xm(2)-(Xm(2)-Xm(1))/10-2,Ym(1)+(Ym(2)-Ym(1))/10-5,S2)
text(Xm(2)-(Xm(2)-Xm(1))/10,Ym(1)+(Ym(2)-Ym(1))/10,'(c)')
xlabel('DD/km')
ylabel('D/km')
axis equal
set(gca,'LineWidth',1)
%colorbar

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 4
subplot(2,2,4)
 XX=datr2';
 [N,X]=hist(XX(:,3),40);
 bar(X,N,'k');
if(phi<=pi/2)
S1=sprintf('N%3.0f^oW',rad2deg(pi/2-phi));
S2=sprintf('S%3.0f^oE',rad2deg(pi/2-phi));
elseif(phi>pi/2&phi<=pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-pi/2));
S2=sprintf('S%3.0f^oW',rad2deg(phi-pi/2));
elseif(phi>pi&phi<=3*pi/2)
S1=sprintf('S%3.0f^oE',rad2deg(3/2*pi-phi));
S2=sprintf('N%3.0f^oW',rad2deg(3/2*pi-phi));
elseif(phi>3/2*pi&phi<=2*pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-3/2*pi));
S2=sprintf('S%3.0f^oW',rad2deg(phi-3/2*pi));
end
xlim([-5 5])
Xm=xlim;Ym=ylim;
text(Xm(1)+(Xm(2)-Xm(1))/10-3,Ym(1)+(Ym(2)-Ym(1))/10-5,S2)
text(Xm(2)-(Xm(2)-Xm(1))/10,Ym(1)+(Ym(2)-Ym(1))/10-5,S1)
 xlabel('DF/km')
 ylabel('F')
text(Xm(2)-(Xm(2)-Xm(1))/10,Ym(2)-(Ym(2)-Ym(1))/10,'(d)')
set(gca,'LineWidth',1)
 Indexdel=find(abs(XX(:,3))>=6);   %%%
 R11=[cos(phirad) -sin(phirad) 0;sin(phirad) cos(phirad) 0;0 0 1 ];
R22 = [1 0  0;0 cos(deltarad)  -sin(deltarad);0 sin(deltarad) cos(deltarad)];
X=R11*(R22*P');
%Y=R1*(R2*X);
%P
%Y
%��������
c1 = 111.199;
P1=X';
latP=P1(:,1)/ c1+mean(lat);
rlatP = (latP+mean(latP))*pi/360;
longP=P1(:,2)./cos(rlatP)/c1+mean(long);
%The four point of fault plane
dep=X';
[latP,longP,dep(:,3)+mean(deep)];
longP';   %%%
latP';    %%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 1
subplot(2,2,1)
%scatter(dataori(:,3),dataori(:,2),(dataori(:,17)+1).^2,dat(:,4))
scatter(dataori(:,1),dataori(:,2),(dataori(:,3)+1).^2,'k')
hold on
plot(longP,latP,'k','LineWidth',2)
text(longP(1)+0.1,latP(1),'A')
text(longP(4)+0.1,latP(4),'A''')
%%%%%%%%%%%%%%%%%%%%%%  datasouth
%xlim([117.7 118.3]) 
%ylim([39.68 39.9])
%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set(gca,'DataAspectRatio',[1 cos(deg2rad(sum(ylim)/2))  1],'box','on')
%axis equal
Xm=xlim;Ym=ylim;
text(Xm(2)-(Xm(2)-Xm(1))/10+0.3,Ym(2)-(Ym(2)-Ym(1))/10-0.35,'(a)')
% xlabel('\lambda/^o')
% ylabel('\theta/^o')
set(gca,'box','on','LineWidth',1)
axis equal

% set(gca,'position',[0.05 0.599 0.5 0.326],'LineWidth',2)
%colorbar horizontal

% figure(2)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2
% subplot(2,2,2)
% plot([stredge(1),stredge(1),stredge(2),stredge(2),stredge(1)],[dipedge(1),dipedge(2),dipedge(2),dipedge(1),dipedge(1)],'k','LineWidth',2)
% hold on
% if(phi<=pi/2)
% S1=sprintf('S%3.0f^oW',rad2deg(phi));
% S2=sprintf('N%3.0f^oE',rad2deg(phi));
% elseif(phi>pi/2&phi<=pi)
% S1=sprintf('N%3.0f^oW',rad2deg(pi-phi));
% S2=sprintf('S%3.0f^oE',rad2deg(pi-phi));
% elseif(phi>pi&phi<=3/2*pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-pi));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-pi));
% elseif(phi>3/2*pi&phi<=2*pi)
% S1=sprintf('N%3.0f^oW',rad2deg(2*pi-phi));
% S2=sprintf('S%3.0f^oE',rad2deg(2*pi-phi));
% end
% %scatter(datr2(1,:),datr2(2,:),(dataori(:,17)+1).^2,dat(:,4))
% scatter(datr2(1,:),datr2(2,:),(dataori(:,3)+1).^2,'k')
% set(gca,'box','on')
% set(gca,'Ydir','reverse','box','on')
% axis equal
% Xm=xlim;Ym=ylim;
% % gtext(S1)
% % gtext(S2)
% % gtext('(b)')
% % gtext('A')
% % gtext('A''')
% xlabel('SD/km')
% ylabel('DD/km')
% set(gca,'LineWidth',1)
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 3
% subplot(2,2,3)
% R11=[1 0 0;0 1 0;0 0 1 ];
% R22 = [1 0  0;0 cos(deltarad)  -sin(deltarad);0 sin(deltarad) cos(deltarad)];
% X=R11*(R22*datr2);
% scatter(X(2,:),X(3,:)+dep0,(dataori(:,3)+1).^2,'k')
% PP=R11*(R22*P');
% hold on
% plot(PP(2,:),PP(3,:)+dep0,'k','LineWidth',3)
% if(phi<=pi/2)
% S1=sprintf('N%3.0f^oW',rad2deg(pi/2-phi));
% S2=sprintf('S%3.0f^oE',rad2deg(pi/2-phi));
% elseif(phi>pi/2&phi<=pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-pi/2));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-pi/2));
% elseif(phi>pi&phi<=3*pi/2)
% S1=sprintf('S%3.0f^oE',rad2deg(3/2*pi-phi));
% S2=sprintf('N%3.0f^oW',rad2deg(3/2*pi-phi));
% elseif(phi>3/2*pi&phi<=2*pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-3/2*pi));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-3/2*pi));
% end
% axis equal
% set(gca,'Ydir','reverse','box','on')
% Xm=xlim;Ym=ylim;
% gtext(S1)
% gtext(S2)
% gtext('(c)')
% xlabel('DD/km')
% ylabel('D/km')
% axis equal
% set(gca,'LineWidth',1)
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 4
% subplot(2,2,4)
%  XX=datr2';
%  [N,X]=hist(XX(:,3),40);
%  bar(X,N,'k');
% if(phi<=pi/2)
% S1=sprintf('N%3.0f^oW',rad2deg(pi/2-phi));
% S2=sprintf('S%3.0f^oE',rad2deg(pi/2-phi));
% elseif(phi>pi/2&phi<=pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-pi/2));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-pi/2));
% elseif(phi>pi&phi<=3*pi/2)
% S1=sprintf('S%3.0f^oE',rad2deg(3/2*pi-phi));
% S2=sprintf('N%3.0f^oW',rad2deg(3/2*pi-phi));
% elseif(phi>3/2*pi&phi<=2*pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-3/2*pi));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-3/2*pi));
% end
% xlim([-5 5])
% Xm=xlim;Ym=ylim;
% gtext(S2)
% gtext(S1)
%  xlabel('DF/km')
%  ylabel('F')
% gtext('(d)')
% set(gca,'LineWidth',1)
%  Indexdel=find(abs(XX(:,3))>=6);          %%%
%  R11=[cos(phirad) -sin(phirad) 0;sin(phirad) cos(phirad) 0;0 0 1 ];
% R22 = [1 0  0;0 cos(deltarad)  -sin(deltarad);0 sin(deltarad) cos(deltarad)];
% X=R11*(R22*P');
% 
% c1 = 111.199;
% P1=X';
% latP=P1(:,1)/ c1+mean(lat);
% rlatP = (latP+mean(latP))*pi/360;
% longP=P1(:,2)./cos(rlatP)/c1+mean(long);
% %The four point of fault plane
% dep=X';
% [latP,longP,dep(:,3)+mean(deep)];   %%%
% longP';
% latP';
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 1
% subplot(2,2,1)
% scatter(dataori(:,1),dataori(:,2),(dataori(:,3)+1).^2,'k')
% hold on
% plot(longP,latP,'k','LineWidth',2)
% Xm=xlim;Ym=ylim;
% axis equal
% gtext('A')
% gtext('A''')
% 
% gtext('(a)')
% set(gca,'box','on','LineWidth',1)
