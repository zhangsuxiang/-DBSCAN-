function F = goalvectorJsph(x,dat)
F=[ ];
for k = 1:size(dat,1);
% F = (sin(x(1))*sin(x(2))*dat(k,1) -cos(x(1))*sin( x(2))*dat(k,2) +
% cos(x(2))*dat(k,3) -x(3));
%����x1��ƫ����
f1 = cos(x(1))*sin(x(2))*dat(k,1)+sin(x(1))*sin( x(2))*dat(k,2);
f2 =sin(x(1))*cos(x(2))*dat(k,1) -cos(x(1))*cos( x(2))*dat(k,2)-sin(x(2))*dat(k,3);
f3 =-1 ;
F = [F;[f1, f2, f3]];
end