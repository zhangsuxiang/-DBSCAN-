%%%8���ϲ����ս��
clear;
clc;
close all;
%��ͼ
% tangshan=xlsread('lushan1.xlsx');
tangshan=load('lushan.txt');
dat1=[tangshan(:,2), tangshan(:,3),tangshan(:,14), tangshan(:,4)]; %%% ���ȣ�γ�ȣ��𼶺����                       
figure(1)
scatter(dat1(:,1),dat1(:,2),(dat1(:,3)+1).^2,'k');
text(118.02,39.63,'��ɽ��','FontSize',12);
text(118.70,39.75,'����','FontSize',12);
text(118.87,39.88,'¬����','FontSize',12);
text(118.586,39.755,'��ׯ��','FontSize',12);
text(118.558,39.642,'С��ׯ��','FontSize',12);
text(119.0,39.98,'�¹�����','FontSize',12);
text(117.82,39.33,'������','FontSize',12);
%��ɽ�����϶�-1
tangshan_nanduan=xlsread('1.xlsx');
dat2=[tangshan_nanduan(:,1), tangshan_nanduan(:,2),tangshan_nanduan(:,4), tangshan_nanduan(:,3)];
hold on
scatter(dat2(:,1),dat2(:,2),(dat2(:,4)+1).^1,addcolorplus(2),'*');

%��ɽ���ѱ���-2(���½�)
tangshan_beiduan=xlsread('2.xlsx');
dat3=[tangshan_beiduan(:,1), tangshan_beiduan(:,2),tangshan_beiduan(:,4), tangshan_beiduan(:,3)];
hold on
scatter(dat3(:,1),dat3(:,2),(dat3(:,4)+1).^1,addcolorplus(9),'*');
%С��ׯ���Ѷ�-3�����½ǣ�
xiaomazhuang=xlsread('3.xlsx');
dat4=[xiaomazhuang(:,1), xiaomazhuang(:,2),xiaomazhuang(:,4), xiaomazhuang(:,3)];
hold on
scatter(dat4(:,1),dat4(:,2),(dat4(:,4)+1).^1,'r','*');
,addcolorplus(10),'*');
%��ׯ���Ѷ�-4
leizhuang=xlsread('4.xlsx');
dat5=[leizhuang(:,1), leizhuang(:,2),leizhuang(:,4), leizhuang(:,3)];
hold on
scatter(dat5(:,1),dat5(:,2),(dat5(:,4)+1).^1,addcolorplus(11),'*');
%���ض��Ѷ�-5
luanxian=xlsread('5.xlsx');
dat6=[luanxian(:,1), luanxian(:,2),luanxian(:,4), luanxian(:,3)];
hold on
scatter(dat6(:,1),dat6(:,2),(dat6(:,4)+1).^1,addcolorplus(12),'*');
%�����϶�-6
luanxian_nanduan=xlsread('6.xlsx');
dat7=[luanxian_nanduan(:,1), luanxian_nanduan(:,2),luanxian_nanduan(:,4), luanxian_nanduan(:,3)];
hold on
scatter(dat7(:,1),dat7(:,2),(dat7(:,4)+1).^1,addcolorplus(13),'*');
%¬�����Ѷ�-7
lulong=xlsread('7.xlsx');
dat8=[lulong(:,1), lulong(:,2),lulong(:,4), lulong(:,3)];
hold on
scatter(dat8(:,1),dat8(:,2),(dat8(:,4)+1).^1,addcolorplus(16),'*');
%�¹��Ͷ��Ѷ�-8
chenguantun=xlsread('11.xlsx');
dat9=[chenguantun(:,1), chenguantun(:,2),chenguantun(:,4), chenguantun(:,3)];
hold on
scatter(dat9(:,1),dat9(:,2),(dat9(:,3)+1).^1,addcolorplus(66),'*');
%10
chenguantun10=xlsread('9.xlsx');
dat10=[chenguantun10(:,1), chenguantun10(:,2),chenguantun10(:,4), chenguantun10(:,3)];
hold on
scatter(dat10(:,1),dat10(:,2),(dat10(:,3)+1).^1,addcolorplus(18),'*');
%11
c11=xlsread('10.xlsx');
dat11=[c11(:,1), c11(:,2),c11(:,4), c11(:,3)];
hold on
scatter(dat11(:,1),dat11(:,2),(dat11(:,3)+1).^1,addcolorplus(49),'*');
%12
% c12=xlsread('11.xlsx');
% dat12=[c12(:,1), c12(:,2),c12(:,4), c12(:,3)];
% hold on
% scatter(dat12(:,1),dat12(:,2),(dat12(:,3)+1).^1,addcolorplus(25),'*');

% %13
% c13=xlsread('18.xlsx');
% dat13=[c13(:,1), c13(:,2),c13(:,4), c13(:,3)];
% hold on
% scatter(dat13(:,1),dat13(:,2),(dat13(:,4)+1).^1,addcolorplus(49),'*');
% %14
c14=xlsread('19and54and86.xlsx');
dat14=[c14(:,1), c14(:,2),c14(:,4), c14(:,3)];
hold on
scatter(dat14(:,1),dat14(:,2),(dat14(:,4)+1).^1,addcolorplus(31),'*');
%15
c15=xlsread('21and58.xlsx');
dat15=[c15(:,1), c15(:,2),c15(:,4), c15(:,3)];
hold on
scatter(dat15(:,1),dat15(:,2),(dat15(:,4)+1).^1,addcolorplus(160),'*');
%16
c16=xlsread('22and50.xlsx');
dat16=[c16(:,1), c16(:,2),c16(:,4), c16(:,3)];
hold on
scatter(dat16(:,1),dat16(:,2),(dat16(:,4)+1).^1,addcolorplus(35),'*');
% %17
c17=xlsread('23and17and51.xlsx');
dat17=[c17(:,1), c17(:,2),c17(:,4), c17(:,3)];
hold on
scatter(dat17(:,1),dat17(:,2),(dat17(:,4)+1).^1,addcolorplus(38),'*');
% %18
c18=xlsread('24and32.xlsx');
dat18=[c18(:,1), c18(:,2),c18(:,4), c18(:,3)];
hold on
scatter(dat18(:,1),dat18(:,2),(dat18(:,4)+1).^1,addcolorplus(42),'*');
%20
c20=xlsread('25.xlsx');
dat20=[c20(:,1), c20(:,2),c20(:,4), c20(:,3)];
hold on
scatter(dat20(:,1),dat20(:,2),(dat20(:,4)+1).^1,addcolorplus(47),'*');
% %21
c21=xlsread('18and26and29and55and87and89.xlsx');
dat21=[c21(:,1), c21(:,2),c21(:,4), c21(:,3)];
hold on
scatter(dat21(:,1),dat21(:,2),(dat21(:,4)+1).^1,addcolorplus(49),'*');
% %22
c22=xlsread('28.xlsx');
dat22=[c22(:,1), c22(:,2),c22(:,4), c22(:,3)];
hold on
scatter(dat22(:,1),dat22(:,2),(dat22(:,4)+1).^1,addcolorplus(51),'*');
% %23
c23=xlsread('30and91.xlsx');
dat23=[c23(:,1), c23(:,2),c23(:,4), c23(:,3)];
hold on
scatter(dat23(:,1),dat23(:,2),(dat23(:,4)+1).^1,addcolorplus(53),'*');
% %24
c24=xlsread('35.xlsx');
dat24=[c24(:,1), c24(:,2),c24(:,4), c24(:,3)];
hold on
scatter(dat24(:,1),dat24(:,2),(dat24(:,4)+1).^1,addcolorplus(58),'*');
% %25
c25=xlsread('36.xlsx');
dat25=[c25(:,1), c25(:,2),c25(:,4), c25(:,3)];
hold on
scatter(dat25(:,1),dat25(:,2),(dat25(:,4)+1).^1,addcolorplus(60),'*');
% %26
c26=xlsread('38and61.xlsx');
dat26=[c26(:,1), c26(:,2),c26(:,4), c26(:,3)];
hold on
scatter(dat26(:,1),dat26(:,2),(dat26(:,4)+1).^1,addcolorplus(61),'*');
% %27
c27=xlsread('40.xlsx');
dat27=[c27(:,1), c27(:,2),c27(:,4), c27(:,3)];
hold on
scatter(dat27(:,1),dat27(:,2),(dat27(:,4)+1).^1,addcolorplus(62),'*');
% %28
c28=xlsread('42.xlsx');
dat28=[c28(:,1), c28(:,2),c28(:,4), c28(:,3)];
hold on
scatter(dat28(:,1),dat28(:,2),(dat28(:,4)+1).^1,addcolorplus(66),'*');
% %29
c29=xlsread('44.xlsx');
dat29=[c29(:,1), c29(:,2),c29(:,4), c29(:,3)];
hold on
scatter(dat29(:,1),dat29(:,2),(dat29(:,4)+1).^1,addcolorplus(68),'*');
% %30
c30=xlsread('48.xlsx');
dat30=[c30(:,1), c30(:,2),c30(:,4), c30(:,3)];
hold on
scatter(dat30(:,1),dat30(:,2),(dat30(:,4)+1).^1,addcolorplus(82),'*');
% %31
c31=xlsread('49.xlsx');
dat31=[c31(:,1), c31(:,2),c31(:,4), c31(:,3)];
hold on
scatter(dat31(:,1),dat31(:,2),(dat31(:,4)+1).^1,addcolorplus(81),'*');
% %32
c32=xlsread('52.xlsx');
dat32=[c32(:,1), c32(:,2),c32(:,4), c32(:,3)];
hold on
scatter(dat32(:,1),dat32(:,2),(dat32(:,4)+1).^1,addcolorplus(87),'*');
% %33
c33=xlsread('56.xlsx');
dat33=[c33(:,1), c33(:,2),c33(:,4), c33(:,3)];
hold on
scatter(dat33(:,1),dat33(:,2),(dat33(:,4)+1).^1,addcolorplus(98),'*');
% %34
c34=xlsread('57.xlsx');
dat34=[c34(:,1), c34(:,2),c34(:,4), c34(:,3)];
hold on
scatter(dat34(:,1),dat34(:,2),(dat34(:,4)+1).^1,addcolorplus(101),'*');
% %35
c35=xlsread('60.xlsx');
dat35=[c35(:,1), c35(:,2),c35(:,4), c35(:,3)];
hold on
scatter(dat35(:,1),dat35(:,2),(dat35(:,4)+1).^1,addcolorplus(102),'*');
% %36
c36=xlsread('63.xlsx');
dat36=[c36(:,1), c36(:,2),c36(:,4), c36(:,3)];
hold on
scatter(dat36(:,1),dat36(:,2),(dat36(:,4)+1).^1,addcolorplus(103),'*');
% %37
c37=xlsread('64.xlsx');
dat37=[c37(:,1), c37(:,2),c37(:,4), c37(:,3)];
hold on
scatter(dat37(:,1),dat37(:,2),(dat37(:,4)+1).^1,addcolorplus(104),'*');
% % %38
c38=xlsread('65.xlsx');
dat38=[c38(:,1), c38(:,2),c38(:,4), c38(:,3)];
hold on
scatter(dat38(:,1),dat38(:,2),(dat38(:,4)+1).^1,addcolorplus(106),'*');
% % %39
c39=xlsread('68.xlsx');
dat39=[c39(:,1), c39(:,2),c39(:,4), c39(:,3)];
hold on
scatter(dat39(:,1),dat39(:,2),(dat39(:,4)+1).^1,addcolorplus(107),'*');
% % %40
c40=xlsread('69.xlsx');
dat40=[c40(:,1), c40(:,2),c40(:,4), c40(:,3)];
hold on
scatter(dat40(:,1),dat40(:,2),(dat40(:,4)+1).^1,addcolorplus(108),'*');
% % %41
c41=xlsread('71.xlsx');
dat41=[c41(:,1), c41(:,2),c41(:,4), c41(:,3)];
hold on
scatter(dat41(:,1),dat41(:,2),(dat41(:,4)+1).^1,addcolorplus(111),'*');
% % %42
c42=xlsread('72.xlsx');
dat42=[c42(:,1), c42(:,2),c42(:,4), c42(:,3)];
hold on
scatter(dat42(:,1),dat42(:,2),(dat42(:,4)+1).^1,addcolorplus(115),'*');
% % %43
c43=xlsread('73.xlsx');
dat43=[c43(:,1), c43(:,2),c43(:,4), c43(:,3)];
hold on
scatter(dat43(:,1),dat43(:,2),(dat43(:,4)+1).^1,addcolorplus(116),'*');
% % %44
c44=xlsread('75.xlsx');
dat44=[c44(:,1), c44(:,2),c44(:,4), c44(:,3)];
hold on
scatter(dat44(:,1),dat44(:,2),(dat44(:,4)+1).^1,addcolorplus(117),'*');
% % %45
c45=xlsread('76.xlsx');
dat45=[c45(:,1), c45(:,2),c45(:,4), c45(:,3)];
hold on
scatter(dat45(:,1),dat45(:,2),(dat45(:,4)+1).^1,addcolorplus(120),'*');
% % %46
c46=xlsread('77.xlsx');
dat46=[c46(:,1), c46(:,2),c46(:,4), c46(:,3)];
hold on
scatter(dat46(:,1),dat46(:,2),(dat46(:,4)+1).^1,addcolorplus(121),'*');
% % %47
c47=xlsread('78.xlsx');
dat47=[c47(:,1), c47(:,2),c47(:,4), c47(:,3)];
hold on
scatter(dat47(:,1),dat47(:,2),(dat47(:,4)+1).^1,addcolorplus(126),'*');
% % %48
c48=xlsread('79.xlsx');
dat48=[c48(:,1), c48(:,2),c48(:,4), c48(:,3)];
hold on
scatter(dat48(:,1),dat48(:,2),(dat48(:,4)+1).^1,addcolorplus(128),'*');
% % %49
c49=xlsread('80.xlsx');
dat49=[c49(:,1), c49(:,2),c49(:,4), c49(:,3)];
hold on
scatter(dat49(:,1),dat49(:,2),(dat49(:,4)+1).^1,addcolorplus(129),'*');
% % %50
c50=xlsread('82.xlsx');
dat50=[c50(:,1), c50(:,2),c50(:,4), c50(:,3)];
hold on
scatter(dat50(:,1),dat50(:,2),(dat50(:,4)+1).^1,addcolorplus(132),'*');
% % %51
c51=xlsread('83.xlsx');
dat51=[c51(:,1), c51(:,2),c51(:,4), c51(:,3)];
hold on
scatter(dat51(:,1),dat51(:,2),(dat51(:,4)+1).^1,addcolorplus(135),'*');
% % %52
c52=xlsread('84.xlsx');
dat52=[c52(:,1), c52(:,2),c52(:,4), c52(:,3)];
hold on
scatter(dat52(:,1),dat52(:,2),(dat52(:,4)+1).^1,addcolorplus(154),'*');
% % %53
c53=xlsread('88.xlsx');
dat53=[c53(:,1), c53(:,2),c53(:,4), c53(:,3)];
hold on
scatter(dat53(:,1),dat53(:,2),(dat53(:,4)+1).^1,addcolorplus(141),'*');
% % % %54
% c54=xlsread('62.xlsx');
% dat54=[c54(:,1), c54(:,2),c54(:,4), c54(:,3)];
% hold on
% scatter(dat54(:,1),dat54(:,2),(dat54(:,4)+1).^1,addcolorplus(143),'*');
% % % %55
% c55=xlsread('63.xlsx');
% dat55=[c55(:,1), c55(:,2),c55(:,4), c55(:,3)];
% hold on
% scatter(dat55(:,1),dat55(:,2),(dat55(:,4)+1).^1,addcolorplus(144),'*');
% % % %56
% c56=xlsread('64.xlsx');
% dat56=[c56(:,1), c56(:,2),c56(:,4), c56(:,3)];
% hold on
% scatter(dat56(:,1),dat56(:,2),(dat56(:,4)+1).^1,addcolorplus(145),'*');
% % % %57
% c57=xlsread('65.xlsx');
% dat57=[c57(:,1), c57(:,2),c57(:,4), c57(:,3)];
% hold on
% scatter(dat57(:,1),dat57(:,2),(dat57(:,4)+1).^1,addcolorplus(148),'*');
% % % %58
% c58=xlsread('66.xlsx');
% dat58=[c58(:,1), c58(:,2),c58(:,4), c58(:,3)];
% hold on
% scatter(dat58(:,1),dat58(:,2),(dat58(:,4)+1).^1,addcolorplus(150),'*');
% % % %59
% c59=xlsread('67.xlsx');
% dat59=[c59(:,1), c59(:,2),c59(:,4), c59(:,3)];
% hold on
% scatter(dat59(:,1),dat59(:,2),(dat59(:,4)+1).^1,addcolorplus(151),'*');
% % % %60
% c60=xlsread('68.xlsx');
% dat60=[c60(:,1), c60(:,2),c60(:,4), c60(:,3)];
% hold on
% scatter(dat60(:,1),dat60(:,2),(dat60(:,4)+1).^1,addcolorplus(152),'*');
% % % %61
% c61=xlsread('69.xlsx');
% dat61=[c61(:,1), c61(:,2),c61(:,4), c61(:,3)];
% hold on
% scatter(dat61(:,1),dat61(:,2),(dat61(:,4)+1).^1,addcolorplus(153),'*');
% % % %62
% c62=xlsread('70.xlsx');
% dat62=[c62(:,1), c62(:,2),c62(:,4), c62(:,3)];
% hold on
% scatter(dat62(:,1),dat62(:,2),(dat62(:,4)+1).^1,addcolorplus(154),'*');
% % % %63
% c63=xlsread('71.xlsx');
% dat63=[c63(:,1), c63(:,2),c63(:,4), c63(:,3)];
% hold on
% scatter(dat63(:,1),dat63(:,2),(dat63(:,4)+1).^1,addcolorplus(155),'*');
% % % %64
% c64=xlsread('72.xlsx');
% dat64=[c64(:,1), c64(:,2),c64(:,4), c64(:,3)];
% hold on
% scatter(dat64(:,1),dat64(:,2),(dat64(:,4)+1).^1,addcolorplus(156),'*');
% % % %65
% c65=xlsread('73.xlsx');
% dat65=[c65(:,1), c65(:,2),c65(:,4), c65(:,3)];
% hold on
% scatter(dat65(:,1),dat65(:,2),(dat65(:,4)+1).^1,addcolorplus(157),'*');
% % % %66
% c66=xlsread('74.xlsx');
% dat66=[c66(:,1), c66(:,2),c66(:,4), c66(:,3)];
% hold on
% scatter(dat66(:,1),dat66(:,2),(dat66(:,4)+1).^1,addcolorplus(158),'*');
% % % %67
% c67=xlsread('75.xlsx');
% dat67=[c67(:,1), c67(:,2),c67(:,4), c67(:,3)];
% hold on
% scatter(dat67(:,1),dat67(:,2),(dat67(:,4)+1).^1,addcolorplus(159),'*');
% % % %68
% c68=xlsread('76.xlsx');
% dat68=[c68(:,1), c68(:,2),c68(:,4), c68(:,3)];
% hold on
% scatter(dat68(:,1),dat68(:,2),(dat68(:,4)+1).^1,addcolorplus(160),'*');
% % % %69
% c69=xlsread('77.xlsx');
% dat69=[c69(:,1), c69(:,2),c69(:,4), c69(:,3)];
% hold on
% scatter(dat69(:,1),dat69(:,2),(dat69(:,4)+1).^1,addcolorplus(161),'*');
% % % %70
% c70=xlsread('78.xlsx');
% dat70=[c70(:,1), c70(:,2),c70(:,4), c70(:,3)];
% hold on
% scatter(dat70(:,1),dat70(:,2),(dat70(:,4)+1).^1,addcolorplus(162),'*');
% % % %71
% c71=xlsread('79.xlsx');
% dat71=[c71(:,1), c71(:,2),c71(:,4), c71(:,3)];
% hold on
% scatter(dat71(:,1),dat71(:,2),(dat71(:,4)+1).^1,addcolorplus(240),'*');
% % % %72
% c72=xlsread('80.xlsx');
% dat72=[c72(:,1), c72(:,2),c72(:,4), c72(:,3)];
% hold on
% scatter(dat72(:,1),dat72(:,2),(dat72(:,4)+1).^1,addcolorplus(163),'*');
% % % %73
% c73=xlsread('81.xlsx');
% dat73=[c73(:,1), c73(:,2),c73(:,4), c73(:,3)];
% hold on
% scatter(dat73(:,1),dat73(:,2),(dat73(:,4)+1).^1,addcolorplus(164),'*');
% % % %74
% c74=xlsread('82.xlsx');
% dat74=[c74(:,1), c74(:,2),c74(:,4), c74(:,3)];
% hold on
% scatter(dat74(:,1),dat74(:,2),(dat74(:,4)+1).^1,addcolorplus(165),'*');
% % % %75
% c75=xlsread('83.xlsx');
% dat75=[c75(:,1), c75(:,2),c75(:,4),c75(:,3)];
% hold on
% scatter(dat75(:,1),dat75(:,2),(dat75(:,4)+1).^1,addcolorplus(166),'*');
% % % %76
% c76=xlsread('84.xlsx');
% dat76=[c76(:,1), c76(:,2),c76(:,4), c76(:,3)];
% hold on
% scatter(dat76(:,1),dat76(:,2),(dat76(:,4)+1).^1,addcolorplus(167),'*');
% % % %77
% c77=xlsread('85.xlsx');
% dat77=[c77(:,1), c77(:,2),c77(:,4), c77(:,3)];
% hold on
% scatter(dat77(:,1),dat77(:,2),(dat77(:,4)+1).^1,addcolorplus(168),'*');
% % % %78
% c78=xlsread('86.xlsx');
% dat78=[c78(:,1), c78(:,2),c78(:,4), c78(:,3)];
% hold on
% scatter(dat78(:,1),dat78(:,2),(dat78(:,4)+1).^1,addcolorplus(169),'*');
% % % %79
% c79=xlsread('87.xlsx');
% dat79=[c79(:,1), c79(:,2),c79(:,4), c79(:,3)];
% hold on
% scatter(dat79(:,1),dat79(:,2),(dat79(:,4)+1).^1,addcolorplus(170),'*');
% % % %80
% c80=xlsread('88.xlsx');
% dat80=[c80(:,1), c80(:,2),c80(:,4), c80(:,3)];
% hold on
% scatter(dat80(:,1),dat80(:,2),(dat80(:,4)+1).^1,addcolorplus(171),'*');
% % % %81
% c81=xlsread('89.xlsx');
% dat81=[c81(:,1), c81(:,2),c81(:,4), c81(:,3)];
% hold on
% scatter(dat81(:,1),dat81(:,2),(dat81(:,4)+1).^1,addcolorplus(172),'*');
% % % %82
% c82=xlsread('90.xlsx');
% dat82=[c82(:,1), c82(:,2),c82(:,4), c82(:,3)];
% hold on
% scatter(dat82(:,1),dat82(:,2),(dat82(:,4)+1).^1,addcolorplus(173),'*');
% % % %83
% c83=xlsread('91.xlsx');
% dat83=[c83(:,1), c83(:,2),c83(:,4),c83(:,3)];
% hold on
% scatter(dat83(:,1),dat83(:,2),(dat83(:,4)+1).^1,addcolorplus(174),'*');
%���ֱ��
line([118.1,118.5],[39.5,39.8],'color','r','linewidth',3);
line([118.18,117.78],[39.5,39.25],'color','r','linewidth',3);
line([118.37,118.675],[39.605,39.8],'color','r','linewidth',3);
line([118.484,118.5],[39.636,39.702],'color','r','linewidth',3);
line([118.642,118.707],[39.717,39.8],'color','r','linewidth',3);
line([118.707,118.786],[39.758,39.697],'color','r','linewidth',3);
line([118.735,118.825],[39.775,39.887],'color','r','linewidth',3);
line([118.8239,118.9831],[39.96,39.965],'color','r','linewidth',3);

legend('�����¼�','��ɽ���ѱ���','���ض��Ѷ�','���ض��ѱ���','С��ׯ���Ѷ�','�������Ѷ�','�¹��Ͷ��Ѷ�','¬�����Ѷ�','С��ׯ�����϶�');
text(119.4,39.9,'(e)');
xlabel('����/��');
ylabel('γ��/��');
set(gca,'XLim',[117.2 119.6]);
% for i = 1:11
%     str = num2str(i);
%     text(118.5,39.3,str,'FontSize',20,'Color','red');
% end
grid on;
set(gca,'box','on');
daspect([5 6 1]);
% 
%  text(118.5, 39.6,'1','FontSize',22,'Color','red');
%text(118.75, 39.6,'1','FontSize',22,'Color','red');
% text(118.75, 39.9,'7','FontSize',22,'Color','red');
% text(118.65, 39.63,'5','FontSize',22,'Color','red');
% text(119.01, 39.95,'8','FontSize',22,'Color','red');
% text(118.01, 39.62,'1','FontSize',22,'Color','red');
% text(118.55, 39.85,'4','FontSize',22,'Color','red');