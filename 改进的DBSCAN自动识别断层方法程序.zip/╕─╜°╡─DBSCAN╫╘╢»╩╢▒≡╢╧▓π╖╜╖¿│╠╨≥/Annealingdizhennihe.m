function [sol,Energy] = Annealingdizhennihe(sol,dat,T,Energy,maxTrialN)
TrialN =0 ; 
n=length(sol);
while TrialN < maxTrialN
    x0=sol;
     %%%%%%%%%%%%%%%%%%%%%%%%%
    %���ڶ�ά����ʱ���ı�һ����ͬʱ�ı������ٶȿ�
    %    ���ѡȡһ������������ı� 
    deltax =zeros(n,1);
    r =  ceil(n*rand);
    deltax(r,1) = 0.01*randn;%*T^(1/n);%��̬�ֲ���׼�� С�˾��ȸ�,T�¶�T������������Χ���پ�ϸ����
    %%%%%%%%%%%%%%%%%%%%%%%%%
    tempx = x0(r,1)+deltax(r,1);
    x1 = x0; 
    switch r
         case 1
              if (tempx >2*pi)|(tempx <0)
                   x1(r,1)=mod(tempx ,2*pi);   %Cannot greater than 2*pi
              else
                   x1(r,1) = tempx;
              end
          case 2
              if (tempx >pi/2)|(tempx <0)
                  if(tempx <0)
                      x1(r,1)=tempx+pi/2;
                  elseif(tempx>pi/2)
                      x1(r,1)=pi-tempx;
                  end
                  if(x1(1,1)>pi)
                     x1(1,1)=x1(1,1)-pi;
                  else
                     x1(1,1)=x1(1,1)+pi;  
                  end
             else
                   x1(r,1) = tempx;
             end         
         case 3
               x1(r,1) = tempx;
    end

   NewEnergy = dzsjsph_sa(x1,dat); 
   deltaE= NewEnergy - Energy ; 
      if deltaE < 0
          Energy=NewEnergy;sol = x1;
      else if rand<exp(-deltaE/T)
          Energy=NewEnergy;sol=x1;
       end
     %Energy=Energy;sol=x0;  
    %TrialN=TrialN+1;
   end
   TrialN=TrialN+1;
end   
