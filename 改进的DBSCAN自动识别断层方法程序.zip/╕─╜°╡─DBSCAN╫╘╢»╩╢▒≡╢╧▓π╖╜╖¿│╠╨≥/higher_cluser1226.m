%main function��������
%all codes and test data downlown: http://yarpiz.com/255/ypml110-dbscan-clustering 
 % Copyright (c) 2015, Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "license.txt" for license terms.
%
% Project Code: YPML110
% Project Title: Implementation of DBSCAN Clustering in MATLAB
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: S. Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
 
%% test Data
%����������վ��http://archive.ics.uci.edu/ml/machine-learning-databases/iris/
%����ʹ�õ�iris���ݵ�һ���֣����ڵ�3ά�͵�4Ϊ�����������ֶȺã������3��4ά���ݲ���

clear;
clc;
close all;
[filename,filepath]=uigetfile({'*'}, 'ʵ������');
cd(filepath);
data2 = xlsread(filename,'Sheet1');
%% ����
dataori=data2;

% indlat=find((dataori(:,4)>5));
% dataori=dataori(indlat,:);

%ת������ km
lat = dataori(:,2); long = dataori(:,1); deep = dataori(:,4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lat0=mean(lat);
long0=mean(long);
dep0=mean(deep);
% ����ƽ��λ�� m=[39.9458 113.8313]
%[y,x]=gdist(lat,long,lat0,long0);
c1 = 111.199;
x = c1*(lat-lat0);
rlat = (lat+lat0)*pi/360;
y = c1*(long-long0).*cos(rlat);
%z = deep;%r-mean(r);clc
z = deep-dep0; %clc
%dat=[x,y,z,sqrt((dataori(:,8)/1000).^2+(dataori(:,9)/1000).^2+(dataori(:,10)/1000).^2)];
dat=[x,y,z,ones(size(x))];   %Assume that the error is 1
%Because the unit of error in hypoDD is m. 
%The 4 column is error

% tic
bound = [0 2*pi;0 pi/2;-5 5];
[m,n] = size(bound);
%D = bound(:,1);
%U = bound(:,2);
%generate a solution by random
for ii = 1: m
x0(ii,1) =bound(ii,1)+rand*(bound(ii,2)-bound(ii,1)) ;
end
T = 10^3;              % intial temperature
T0 = 0.0001 ;          % final  temperature
alpha = 0.95 ;         % alpha in [0.85 0.98]
eps=10^(-8);           % eps = 0.001;
maxTrialN = 50;
k=0;                   % ���������ļ�����
Energy = dzsjsph_sa(x0,dat);
while ((T>T0)& (Energy>eps)&(k<300))
    k=k+1;
    [x0,Energy] = Annealingdizhennihe(x0,dat,T,Energy,maxTrialN);
%    [x0,Energy] = Annealingbound(x0,dat,T,Energy,maxTrialN,bound);
    T = alpha*T;      % �˻����
end
% toc
% disp('SAA�㷨 ��С������ϲ���[����ǣ�����ǣ���ԭ�����]');
% disp(num2str([rad2deg(x0(1:2,1)); x0(3,1)]'));
% disp('SAA�㷨 ��Ӧ�ķ�����Ϊ');
phi = x0(1,1); delta = x0(2,1);
nv = [sin(phi)*sin(delta), -cos(phi)*sin(delta), cos(delta)];
% disp(num2str(nv));
% disp('SAA�㷨 ��Ӧ�ļ�Сֵ������С�������ƽ����');
% disp(num2str(Energy));

%%%% The follwing is the Newton-Gauss algorithm

%Gauss-Newton������
x0=x0;eps=10^(-7);                 % ����ģ���˻��㷨������������Gauss_Newton
[m,n]=size(dat);
Cd=diag(dat(:,4).^2); 
%Cd=eye(length(dat),length(dat));  % If we cannot find error we use these
Cd_1=inv(Cd);
for i = 1:100
    A = goalvectorJsph(x0',dat);   % Jacobi����
    cvsv=A'*Cd_1*A;
    cvinv=inv(cvsv);
    xx=cvinv*A'*Cd_1*goalvectorsph(x0',dat);
    x1 = x0 -xx;
    R=cvinv*cvsv;
    if norm(x1-x0)>eps
        x0 =x1;
    else
        break;
    end
end
 chsq_dt=xx'*cvsv*xx;
 y=goalvectorsph(x1',dat);
 tot= y'*Cd_1*y;
 chsq_pst = tot - chsq_dt;
 rsl_sum=sum([R(1,1),R(2,2),R(3,3)]);
 rchisq = chsq_pst/(m-rsl_sum);
    sd=[];
    for ii=1:n-1                  % because we add error in 
    sd1=sqrt(cvinv(ii,ii)*rchisq);
%    sd1=sqrt(cvinv(ii,ii));
    sd=[sd,sd1];
    end
    if(x1(2,1)<0)
        x1(2,1)=pi/2-x1(2,1);
         if(x1(1,1)>pi)
          x1(1,1)=x1(1,1)-pi;
        else
          x1(1,1)=x1(1,1)+pi;  
         end
    elseif(x1(2,1)>pi/2)
        x1(2,1)=x1(2,1)-pi/2;
           if(x1(1,1)>pi)
          x1(1,1)=x1(1,1)-pi;
        else
          x1(1,1)=x1(1,1)+pi;  
         end
    end    
sprintf('The iterative number is %d',i) 
disp('G-S�㷨 ��С������ϲ���[����ǣ�����ǣ���ԭ�����]')
disp(num2str([rad2deg(x1(1:2)); x1(3)]'));
% disp('G-S�㷨 ��Ӧ�ķ�����Ϊ')
% phi = x1(1); delta = x1(2);
% nv = [sin(phi)*sin(delta), -cos(phi)*sin(delta), cos(delta)];
% disp(num2str(nv))
% disp('G-S�㷨 ��Ӧ�ļ�Сֵ������С�������ƽ����')

[m,n] = size(dat);
errsumv =zeros(m,1);
x = x1;
for i=1:m
       errsumv(i) = (sin(x(1))*sin(x(2))*dat(i,1) +(-cos(x(1)))*sin( x(2))*dat(i,2) + cos(x(2))*dat(i,3) -x(3))/dat(i,4);
end
errsum=sum(errsumv.^2);
disp(num2str(errsum))
disp('��׼�')
sd
[rad2deg(sd(1:2)) sd(3)];
disp('�ݺ�в�:')
 chsq_pst = tot - chsq_dt
 rsl_sum=sum([R(1,1),R(2,2),R(3,3)]);
disp('ƽ���ݺ�в�:')
 rchisq = chsq_pst/(m-rsl_sum)
%%%    ����Ϊ��ת������     %%%%%%%%%%%
n=size(dat,1);                          % ������
p=0.025;                                % ����ˮƽ
nd= ceil(n*p);                          % ��Ե�������
phirad=x1(1);deltarad =x1(2);
R1=[1 0  0;0 cos(deltarad)  sin(deltarad);0 -sin(deltarad) cos(deltarad)];
R2=[cos(phirad) sin(phirad) 0;-sin(phirad) cos(phirad) 0;0 0 1 ];
datr2=R1*(R2*dat(:,1:3)');
STR = sortrows(datr2',1);
DIP = sortrows(datr2',2);
stredge = [STR(nd,1),  STR(n-nd,1)];
dipedge =  [DIP(nd,2),  DIP(n-nd,2) ];
P=[stredge(1) dipedge(1)  0;...         % left upper point
    stredge(1) dipedge(2)  0;...        % left down point
    stredge(2) dipedge(2)  0;...        % right down point
    stredge(2) dipedge(1)  0;...        % right upper point
    stredge(1) dipedge(1)  0            % left upper point
    ];  
%��Ϊ�ڶϲ����ϣ�����ڶϲ����ϵ�Z����Ϊ��   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2
figure(1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2
subplot(2,2,2)
plot([stredge(1),stredge(1),stredge(2),stredge(2),stredge(1)],[dipedge(1),dipedge(2),dipedge(2),dipedge(1),dipedge(1)],'k','LineWidth',2)
hold on
if(phi<=pi/2)
S1=sprintf('S%3.0f^oW',rad2deg(phi));
S2=sprintf('N%3.0f^oE',rad2deg(phi));
elseif(phi>pi/2&phi<=pi)
S1=sprintf('N%3.0f^oW',rad2deg(pi-phi));
S2=sprintf('S%3.0f^oE',rad2deg(pi-phi));
elseif(phi>pi&phi<=3/2*pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-pi));
S2=sprintf('S%3.0f^oW',rad2deg(phi-pi));
elseif(phi>3/2*pi&phi<=2*pi)
S1=sprintf('N%3.0f^oW',rad2deg(2*pi-phi));
S2=sprintf('S%3.0f^oE',rad2deg(2*pi-phi));
end
%scatter(datr2(1,:),datr2(2,:),(dataori(:,17)+1).^2,dat(:,4))
scatter(datr2(1,:),datr2(2,:),(dataori(:,3)+1).^2,'k')
set(gca,'box','on')
set(gca,'Ydir','reverse','box','on')
axis equal
Xm=xlim;Ym=ylim;
text(Xm(1)+(Xm(2)-Xm(1))/10-4,Ym(1)+(Ym(2)-Ym(1))/10-5,S1)
text(Xm(2)-(Xm(2)-Xm(1))/10+1,Ym(1)+(Ym(2)-Ym(1))/10-5,S2)
text(Xm(2)-(Xm(2)-Xm(1))/10-28,Ym(1)+(Ym(2)-Ym(1))/10+19.75,'(b)')
text(stredge(1)-2,dipedge(1),'A')
text(stredge(2)+2,dipedge(1),'A''')
xlabel('����/km')
ylabel('����/km')
set(gca,'LineWidth',1)
%colorbar

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 3
subplot(2,2,3)
R11=[1 0 0;0 1 0;0 0 1 ];
R22 = [1 0  0;0 cos(deltarad)  -sin(deltarad);0 sin(deltarad) cos(deltarad)];
X=R11*(R22*datr2);
%scatter(X(2,:),X(3,:)+dep0,(dataori(:,17)+1).^2,dat(:,4))
scatter(X(2,:),X(3,:)+dep0,(dataori(:,3)+1).^2,'k')
PP=R11*(R22*P');
hold on
plot(PP(2,:),PP(3,:)+dep0,'k','LineWidth',3)
if(phi<=pi/2)
S1=sprintf('N%3.0f^oW',rad2deg(pi/2-phi));
S2=sprintf('S%3.0f^oE',rad2deg(pi/2-phi));
elseif(phi>pi/2&phi<=pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-pi/2));
S2=sprintf('S%3.0f^oW',rad2deg(phi-pi/2));
elseif(phi>pi&phi<=3*pi/2)
S1=sprintf('S%3.0f^oE',rad2deg(3/2*pi-phi));
S2=sprintf('N%3.0f^oW',rad2deg(3/2*pi-phi));
elseif(phi>3/2*pi&phi<=2*pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-3/2*pi));
S2=sprintf('S%3.0f^oW',rad2deg(phi-3/2*pi));
end
axis equal
set(gca,'Ydir','reverse','box','on')
Xm=xlim;Ym=ylim;
text(Xm(1)+(Xm(2)-Xm(1))/10-3,Ym(1)+(Ym(2)-Ym(1))/10-4,S1)
text(Xm(2)-(Xm(2)-Xm(1))/10,Ym(1)+(Ym(2)-Ym(1))/10-4,S2)
text(Xm(2)-(Xm(2)-Xm(1))/10,Ym(1)+(Ym(2)-Ym(1))/10,'(c)')
xlabel('����/km')
ylabel('���/km')
axis equal
set(gca,'LineWidth',1)
%colorbar

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 4
subplot(2,2,4)
 XX=datr2';
 [N,X]=hist(XX(:,3),40);
 bar(X,N,'k');
if(phi<=pi/2)
S1=sprintf('N%3.0f^oW',rad2deg(pi/2-phi));
S2=sprintf('S%3.0f^oE',rad2deg(pi/2-phi));
elseif(phi>pi/2&phi<=pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-pi/2));
S2=sprintf('S%3.0f^oW',rad2deg(phi-pi/2));
elseif(phi>pi&phi<=3*pi/2)
S1=sprintf('S%3.0f^oE',rad2deg(3/2*pi-phi));
S2=sprintf('N%3.0f^oW',rad2deg(3/2*pi-phi));
elseif(phi>3/2*pi&phi<=2*pi)
S1=sprintf('N%3.0f^oE',rad2deg(phi-3/2*pi));
S2=sprintf('S%3.0f^oW',rad2deg(phi-3/2*pi));
end
xlim([-5 5])
Xm=xlim;Ym=ylim;
text(Xm(1)+(Xm(2)-Xm(1))/10-1,Ym(1)+(Ym(2)-Ym(1))/10+200,S2)   
text(Xm(2)-(Xm(2)-Xm(1))/10,Ym(1)+(Ym(2)-Ym(1))/10+200,S1)
 xlabel('��ϲ���ľ���/km')
 ylabel('����')
text(Xm(2)-(Xm(2)-Xm(1))/10-8.6,Ym(2)-(Ym(2)-Ym(1))/10-1.8,'(d)')
set(gca,'LineWidth',1)
 Indexdel=find(abs(XX(:,3))>=6);   %%%
 R11=[cos(phirad) -sin(phirad) 0;sin(phirad) cos(phirad) 0;0 0 1 ];
R22 = [1 0  0;0 cos(deltarad)  -sin(deltarad);0 sin(deltarad) cos(deltarad)];
X=R11*(R22*P');
%Y=R1*(R2*X);
%P
%Y
%��������
c1 = 111.199;
P1=X';
latP=P1(:,1)/ c1+mean(lat);
rlatP = (latP+mean(latP))*pi/360;
longP=P1(:,2)./cos(rlatP)/c1+mean(long);
%The four point of fault plane
dep=X';
[latP,longP,dep(:,3)+mean(deep)];
longP';   %%%
latP';    %%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 1
subplot(2,2,1)
%scatter(dataori(:,3),dataori(:,2),(dataori(:,17)+1).^2,dat(:,4))
scatter(dataori(:,1),dataori(:,2),(dataori(:,3)+1).^2,'k')
hold on
plot(longP,latP,'k','LineWidth',2)
text(longP(1)-0.01,latP(1)+0.002,'A')
text(longP(4),latP(4)+0.008,'A''')
%%%%%%%%%%%%%%%%%%%%%%  datasouth
%xlim([117.7 118.3]) 
%ylim([39.68 39.9])
%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set(gca,'DataAspectRatio',[1 cos(deg2rad(sum(ylim)/2))  1],'box','on')
%axis equal
Xm=xlim;Ym=ylim;
text(Xm(2)-(Xm(2)-Xm(1))/10,Ym(2)-(Ym(2)-Ym(1))/10-0.14,'(a)')
% xlabel('\lambda/^o')
% ylabel('\theta/^o')
set(gca,'box','on','LineWidth',1)
axis equal



% set(gca,'position',[0.05 0.599 0.5 0.326],'LineWidth',2)
%colorbar horizontal

% figure(2)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2
% subplot(2,2,2)
% plot([stredge(1),stredge(1),stredge(2),stredge(2),stredge(1)],[dipedge(1),dipedge(2),dipedge(2),dipedge(1),dipedge(1)],'k','LineWidth',2)
% hold on
% if(phi<=pi/2)
% S1=sprintf('S%3.0f^oW',rad2deg(phi));
% S2=sprintf('N%3.0f^oE',rad2deg(phi));
% elseif(phi>pi/2&phi<=pi)
% S1=sprintf('N%3.0f^oW',rad2deg(pi-phi));
% S2=sprintf('S%3.0f^oE',rad2deg(pi-phi));
% elseif(phi>pi&phi<=3/2*pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-pi));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-pi));
% elseif(phi>3/2*pi&phi<=2*pi)
% S1=sprintf('N%3.0f^oW',rad2deg(2*pi-phi));
% S2=sprintf('S%3.0f^oE',rad2deg(2*pi-phi));
% end
% %scatter(datr2(1,:),datr2(2,:),(dataori(:,17)+1).^2,dat(:,4))
% scatter(datr2(1,:),datr2(2,:),(dataori(:,3)+1).^2,'k')
% set(gca,'box','on')
% set(gca,'Ydir','reverse','box','on')
% axis equal
% Xm=xlim;Ym=ylim;
% % gtext(S1)
% % gtext(S2)
% % gtext('(b)')
% % gtext('A')
% % gtext('A''')
% xlabel('SD/km')
% ylabel('DD/km')
% set(gca,'LineWidth',1)
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 3
% subplot(2,2,3)
% R11=[1 0 0;0 1 0;0 0 1 ];
% R22 = [1 0  0;0 cos(deltarad)  -sin(deltarad);0 sin(deltarad) cos(deltarad)];
% X=R11*(R22*datr2);
% scatter(X(2,:),X(3,:)+dep0,(dataori(:,3)+1).^2,'k')
% PP=R11*(R22*P');
% hold on
% plot(PP(2,:),PP(3,:)+dep0,'k','LineWidth',3)
% if(phi<=pi/2)
% S1=sprintf('N%3.0f^oW',rad2deg(pi/2-phi));
% S2=sprintf('S%3.0f^oE',rad2deg(pi/2-phi));
% elseif(phi>pi/2&phi<=pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-pi/2));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-pi/2));
% elseif(phi>pi&phi<=3*pi/2)
% S1=sprintf('S%3.0f^oE',rad2deg(3/2*pi-phi));
% S2=sprintf('N%3.0f^oW',rad2deg(3/2*pi-phi));
% elseif(phi>3/2*pi&phi<=2*pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-3/2*pi));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-3/2*pi));
% end
% axis equal
% set(gca,'Ydir','reverse','box','on')
% Xm=xlim;Ym=ylim;
% gtext(S1)
% gtext(S2)
% gtext('(c)')
% xlabel('DD/km')
% ylabel('D/km')
% axis equal
% set(gca,'LineWidth',1)
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 4
% subplot(2,2,4)
%  XX=datr2';
%  [N,X]=hist(XX(:,3),40);
%  bar(X,N,'k');
% if(phi<=pi/2)
% S1=sprintf('N%3.0f^oW',rad2deg(pi/2-phi));
% S2=sprintf('S%3.0f^oE',rad2deg(pi/2-phi));
% elseif(phi>pi/2&phi<=pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-pi/2));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-pi/2));
% elseif(phi>pi&phi<=3*pi/2)
% S1=sprintf('S%3.0f^oE',rad2deg(3/2*pi-phi));
% S2=sprintf('N%3.0f^oW',rad2deg(3/2*pi-phi));
% elseif(phi>3/2*pi&phi<=2*pi)
% S1=sprintf('N%3.0f^oE',rad2deg(phi-3/2*pi));
% S2=sprintf('S%3.0f^oW',rad2deg(phi-3/2*pi));
% end
% xlim([-5 5])
% Xm=xlim;Ym=ylim;
% gtext(S2)
% gtext(S1)
%  xlabel('DF/km')
%  ylabel('F')
% gtext('(d)')
% set(gca,'LineWidth',1)
%  Indexdel=find(abs(XX(:,3))>=6);          %%%
%  R11=[cos(phirad) -sin(phirad) 0;sin(phirad) cos(phirad) 0;0 0 1 ];
% R22 = [1 0  0;0 cos(deltarad)  -sin(deltarad);0 sin(deltarad) cos(deltarad)];
% X=R11*(R22*P');
% 
% c1 = 111.199;
% P1=X';
% latP=P1(:,1)/ c1+mean(lat);
% rlatP = (latP+mean(latP))*pi/360;
% longP=P1(:,2)./cos(rlatP)/c1+mean(long);
% %The four point of fault plane
% dep=X';
% [latP,longP,dep(:,3)+mean(deep)];   %%%
% longP';
% latP';
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 1
% subplot(2,2,1)
% scatter(dataori(:,1),dataori(:,2),(dataori(:,3)+1).^2,'k')
% hold on
% plot(longP,latP,'k','LineWidth',2)
% Xm=xlim;Ym=ylim;
% axis equal
% gtext('A')
% gtext('A''')
% 
% gtext('(a)')
% set(gca,'box','on','LineWidth',1)
