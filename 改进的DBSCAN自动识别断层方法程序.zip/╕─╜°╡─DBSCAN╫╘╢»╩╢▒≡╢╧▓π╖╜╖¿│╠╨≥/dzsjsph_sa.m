function f = dzsjsph_sa(sol,dat);
[m,n] = size(dat);
x = sol(1:3);
for i=1:m
       D(i) = (sin(x(1))*sin(x(2))*dat(i,1) +(-cos(x(1)))*sin( x(2))*dat(i,2) + cos(x(2))*dat(i,3) -x(3));
        %fitval(i)= (dat(i,:)*x'-1)^2/(x*x'); %  ��С����
        %fitval(i)= abs(dat(i,:)*x'-1)/sqrt(x*x'); %  ��Сһ��
end
%f=sum(abs(D));
err=[dat(:,4)]';
f=sum(D.^2./err.^2);
