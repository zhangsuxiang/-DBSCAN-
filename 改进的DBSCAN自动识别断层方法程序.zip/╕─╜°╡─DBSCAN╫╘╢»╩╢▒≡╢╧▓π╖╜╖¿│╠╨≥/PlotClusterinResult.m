function PlotClusterinResult(IDX,data)
k=max(IDX);
Colors=hsv(k);
for num=0:k
    Xi=data(IDX==num,:);
    if num==1
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==2
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==3
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==4
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==5
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==6
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==7
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==8
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==9
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==10
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==11
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==12
        Style = 'X';
        CColor = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==13
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==14
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==15
        Style = 'X';
        CColor = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==16
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==17
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==18
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==19
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==20
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==21
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==22
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==23
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==24
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==25
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==26
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==27
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==28
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==29
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==30
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==31
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==32
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==33
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==34
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==35
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==36
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==37
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==38
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==39
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==40
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==41
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==42
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==43
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==44
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==45
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==46
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==47
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==48
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==49
        Style ='X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==50
        Style = 'X';
        Color = Colors(num,:);
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    elseif num==0
        Style = 'o';
        Color = [0 0 0];
        scatter(Xi(:,1),Xi(:,2),(Xi(:,3)+1).^2,Color,Style);
        hold on
    end
end

hold off;
axis equal;
grid on;
legend('1','2','3','4','5');
end

