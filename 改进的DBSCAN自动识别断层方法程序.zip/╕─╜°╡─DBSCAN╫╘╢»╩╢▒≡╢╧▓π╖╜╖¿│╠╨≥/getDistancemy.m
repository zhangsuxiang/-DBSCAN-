function D= getDistancemy(X)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
n=size(X,1);

D=zeros(n,n);
for i=1:n
    for j=1:n
%         D(i,j)=SphereDist2(X(i,:),X(j,:));      %��ά���빫ʽ
      D(i,j)=SphereDist(X(i,:),X(j,:));       %��ά���빫ʽ
    end
end