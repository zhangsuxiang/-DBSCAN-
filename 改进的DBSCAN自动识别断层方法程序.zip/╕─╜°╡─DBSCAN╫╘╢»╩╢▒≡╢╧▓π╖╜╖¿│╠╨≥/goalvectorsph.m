function F = goalvectorsph(x,dat)
k = 1:size(dat,1);
% F = abs(x(1)*dat(k,1) + x(2)*dat(k,2) + x(3)*dat(k,3) -1)./sqrt(x*x');
F = (sin(x(1))*sin(x(2))*dat(k,1) +(-cos(x(1)))*sin( x(2))*dat(k,2) + cos(x(2))*dat(k,3) -x(3));